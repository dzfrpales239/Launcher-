package com.example.launcher

import android.content.*
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

// ───────────────────────── Activity ─────────────────────────

class MainActivity : ComponentActivity() {
    private val homeSignal = mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val transparent = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        enableEdgeToEdge(statusBarStyle = transparent, navigationBarStyle = transparent)
        val prefs = Prefs(this)
        setContent { LauncherRoot(prefs, homeSignal.intValue) }
    }

    // Appui sur le bouton Home : on revient à l'écran d'accueil
    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        homeSignal.intValue++
    }
}

// ───────────────────────── Données ─────────────────────────

class AppItem(val label: String, val pkg: String, val cls: String, val icon: ImageBitmap)

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    var accent by mutableIntStateOf(sp.getInt("accent", 0xFF7C4DFF.toInt())); private set
    var columns by mutableIntStateOf(sp.getInt("columns", 4)); private set
    var iconSize by mutableIntStateOf(sp.getInt("iconSize", 56)); private set
    var dim by mutableFloatStateOf(sp.getFloat("dim", 0.45f)); private set
    var dock by mutableStateOf(sp.getString("dock", "")!!.split("|").filter { it.isNotEmpty() }); private set

    fun setAccent(v: Int) { accent = v; sp.edit().putInt("accent", v).apply() }
    fun setColumns(v: Int) { columns = v; sp.edit().putInt("columns", v).apply() }
    fun setIconSize(v: Int) { iconSize = v; sp.edit().putInt("iconSize", v).apply() }
    fun setDim(v: Float) { dim = v; sp.edit().putFloat("dim", v).apply() }
    fun togglePin(pkg: String) {
        dock = if (pkg in dock) dock - pkg else if (dock.size < 5) dock + pkg else dock
        sp.edit().putString("dock", dock.joinToString("|")).apply()
    }
}

suspend fun loadApps(ctx: Context): List<AppItem> = withContext(Dispatchers.Default) {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map {
            AppItem(
                it.loadLabel(pm).toString(),
                it.activityInfo.packageName,
                it.activityInfo.name,
                it.loadIcon(pm).toBitmap(160, 160).asImageBitmap()
            )
        }
        .sortedBy { it.label.lowercase() }
}

fun launchApp(ctx: Context, app: AppItem) {
    val i = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setClassName(app.pkg, app.cls)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    runCatching { ctx.startActivity(i) }
}

val swatches = listOf(
    0xFF7C4DFF, 0xFF00BCD4, 0xFFFF4081, 0xFFFF9800,
    0xFF4CAF50, 0xFF2196F3, 0xFFF44336, 0xFFFFEB3B
).map { it.toInt() }

// ───────────────────────── Écran principal ─────────────────────────

@Composable
fun LauncherRoot(prefs: Prefs, homeSignal: Int) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    var refresh by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    val progress = remember { Animatable(0f) }
    val spring = remember { spring<Float>(dampingRatio = 0.85f, stiffness = 320f) }
    val accent = Color(prefs.accent)

    // Recharge la liste quand une appli est installée / désinstallée
    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { refresh++ }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(ctx, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        onDispose { ctx.unregisterReceiver(receiver) }
    }
    LaunchedEffect(refresh) { apps = loadApps(ctx) }

    LaunchedEffect(homeSignal) {
        if (homeSignal > 0) { showSettings = false; progress.animateTo(0f, spring) }
    }

    BackHandler(enabled = showSettings || progress.value > 0f) {
        if (showSettings) showSettings = false
        else scope.launch { progress.animateTo(0f, spring) }
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val hPx = constraints.maxHeight.toFloat()
        val drawerVisible by remember { derivedStateOf { progress.value > 0f } }

        // Voile coloré sur le fond d'écran
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(accent.copy(alpha = 0.20f), Color.Black.copy(alpha = prefs.dim))
                )
            )
        )

        // ── Accueil ──
        Column(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    alpha = 1f - progress.value
                    val s = 1f - 0.06f * progress.value
                    scaleX = s; scaleY = s
                }
                .pointerInput(Unit) {
                    detectVerticalDragGestures(
                        onDragEnd = {
                            scope.launch { progress.animateTo(if (progress.value > 0.25f) 1f else 0f, spring) }
                        },
                        onDragCancel = {
                            scope.launch { progress.animateTo(if (progress.value > 0.25f) 1f else 0f, spring) }
                        },
                        onVerticalDrag = { change, drag ->
                            change.consume()
                            scope.launch {
                                progress.snapTo((progress.value - drag / (hPx * 0.7f)).coerceIn(0f, 1f))
                            }
                        }
                    )
                }
                .pointerInput(Unit) { detectTapGestures(onLongPress = { showSettings = true }) }
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 24.dp)
        ) {
            Clock(accent)
            Spacer(Modifier.weight(1f))
            Text(
                "⌃", color = Color.White.copy(alpha = 0.5f), fontSize = 22.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )
            Spacer(Modifier.height(8.dp))
            Dock(apps, prefs, accent) { launchApp(ctx, it) }
        }

        // ── Tiroir d'applis ──
        if (drawerVisible) {
            Drawer(
                apps = apps, prefs = prefs, accent = accent,
                modifier = Modifier.graphicsLayer {
                    translationY = (1f - progress.value) * hPx * 0.6f
                    alpha = progress.value
                },
                onNestedDrag = { dy ->
                    scope.launch { progress.snapTo((progress.value - dy / hPx).coerceIn(0f, 1f)) }
                },
                onNestedRelease = {
                    scope.launch { progress.animateTo(if (progress.value > 0.7f) 1f else 0f, spring) }
                },
                onLaunch = { launchApp(ctx, it) }
            )
        }

        // ── Réglages ──
        if (showSettings) {
            Box(
                Modifier.fillMaxSize().clickable(
                    interactionSource = remember { MutableInteractionSource() }, indication = null
                ) { showSettings = false }
            )
        }
        AnimatedVisibility(
            visible = showSettings,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.85f, stiffness = 300f)) { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            SettingsPanel(prefs, accent)
        }
    }
}

// ───────────────────────── Horloge ─────────────────────────

@Composable
fun Clock(accent: Color) {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(60_000L - now % 60_000L + 50L)
        }
    }
    val pattern = if (android.text.format.DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm"
    val time = SimpleDateFormat(pattern, Locale.getDefault()).format(Date(now))
    val date = SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(Date(now))
        .replaceFirstChar { it.uppercase() }

    Column(Modifier.padding(top = 32.dp)) {
        Text(time, color = Color.White, fontSize = 84.sp, fontWeight = FontWeight.Thin)
        Text(date, color = accent, fontSize = 18.sp, fontWeight = FontWeight.Medium)
    }
}

// ───────────────────────── Dock ─────────────────────────

@Composable
fun Dock(apps: List<AppItem>, prefs: Prefs, accent: Color, onLaunch: (AppItem) -> Unit) {
    val dockApps = prefs.dock.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(32.dp))
            .background(accent.copy(alpha = 0.22f))
            .border(1.dp, accent.copy(alpha = 0.5f), RoundedCornerShape(32.dp))
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        if (dockApps.isEmpty()) {
            Text(
                "Appui long sur une appli (dans le tiroir) pour l'épingler ici",
                color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(12.dp)
            )
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                dockApps.forEach {
                    AppCell(it, prefs.iconSize.dp, true, false, accent, { onLaunch(it) }) { prefs.togglePin(it.pkg) }
                }
            }
        }
    }
}

// ───────────────────────── Tiroir ─────────────────────────

@Composable
fun Drawer(
    apps: List<AppItem>, prefs: Prefs, accent: Color, modifier: Modifier,
    onNestedDrag: (Float) -> Unit, onNestedRelease: () -> Unit, onLaunch: (AppItem) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered = remember(apps, query) {
        if (query.isBlank()) apps else apps.filter { it.label.contains(query, ignoreCase = true) }
    }
    val connection = remember {
        object : NestedScrollConnection {
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (available.y > 0f && source == NestedScrollSource.UserInput) {
                    onNestedDrag(available.y)
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }
            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                onNestedRelease()
                return Velocity.Zero
            }
        }
    }

    Column(
        modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color.Black.copy(alpha = 0.85f), lerp(Color.Black, accent, 0.35f).copy(alpha = 0.95f))
                )
            )
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        BasicTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 17.sp),
            cursorBrush = SolidColor(accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { filtered.firstOrNull()?.let(onLaunch) }),
            modifier = Modifier
                .padding(horizontal = 20.dp, vertical = 16.dp)
                .fillMaxWidth()
                .clip(RoundedCornerShape(28.dp))
                .background(Color.White.copy(alpha = 0.10f))
                .border(1.dp, accent.copy(alpha = 0.6f), RoundedCornerShape(28.dp))
                .padding(horizontal = 20.dp, vertical = 14.dp),
            decorationBox = { inner ->
                if (query.isEmpty()) Text("Rechercher", color = Color.White.copy(alpha = 0.5f), fontSize = 17.sp)
                inner()
            }
        )
        LazyVerticalGrid(
            columns = GridCells.Fixed(prefs.columns),
            modifier = Modifier.fillMaxSize().nestedScroll(connection),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filtered, key = { it.pkg + it.cls }) { app ->
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    AppCell(app, prefs.iconSize.dp, app.pkg in prefs.dock, true, accent, { onLaunch(app) }) {
                        prefs.togglePin(app.pkg)
                    }
                }
            }
        }
    }
}

// ───────────────────────── Icône d'appli ─────────────────────────

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCell(
    app: AppItem, size: Dp, pinned: Boolean, showLabel: Boolean, accent: Color,
    onClick: () -> Unit, onTogglePin: () -> Unit
) {
    val ctx = LocalContext.current
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.86f else 1f, spring(dampingRatio = 0.5f, stiffness = 500f), label = "press"
    )
    var menu by remember { mutableStateOf(false) }

    Box {
        Column(
            Modifier
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .combinedClickable(
                    interactionSource = source, indication = null,
                    onClick = onClick, onLongClick = { menu = true }
                )
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Image(app.icon, app.label, Modifier.size(size))
            if (showLabel) {
                Text(
                    app.label, color = Color.White, fontSize = 11.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp).widthIn(max = size + 16.dp)
                )
            }
        }
        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }, containerColor = Color(0xFF1E1E24)) {
            DropdownMenuItem(
                text = { Text(if (pinned) "Retirer du dock" else "Épingler au dock", color = Color.White) },
                onClick = { menu = false; onTogglePin() }
            )
            DropdownMenuItem(
                text = { Text("Infos de l'appli", color = Color.White) },
                onClick = {
                    menu = false
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            )
            DropdownMenuItem(
                text = { Text("Désinstaller", color = accent) },
                onClick = {
                    menu = false
                    ctx.startActivity(
                        Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            )
        }
    }
}

// ───────────────────────── Réglages ─────────────────────────

@Composable
fun SettingsPanel(prefs: Prefs, accent: Color) {
    val ctx = LocalContext.current
    var hue by remember { mutableFloatStateOf(0f) }
    val sliderColors = SliderDefaults.colors(
        thumbColor = accent, activeTrackColor = accent, inactiveTrackColor = Color.White.copy(alpha = 0.2f)
    )

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(Color(0xF01A1A1F))
            .navigationBarsPadding()
            .padding(24.dp)
    ) {
        Text("Personnalisation", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(16.dp))

        Text("Couleur", color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp)
        LazyRow(
            Modifier.padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(swatches) { c ->
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(c))
                        .border(
                            if (c == prefs.accent) 3.dp else 0.dp,
                            Color.White, CircleShape
                        )
                        .clickable { prefs.setAccent(c) }
                )
            }
        }
        Slider(
            value = hue, onValueChange = { hue = it; prefs.setAccent(Color.hsv(it, 0.7f, 1f).toArgb()) },
            valueRange = 0f..360f, colors = sliderColors
        )

        SettingSlider("Colonnes : ${prefs.columns}", prefs.columns.toFloat(), 3f..6f, sliderColors, 2) {
            prefs.setColumns(it.toInt())
        }
        SettingSlider("Taille des icônes : ${prefs.iconSize}", prefs.iconSize.toFloat(), 40f..72f, sliderColors, 0) {
            prefs.setIconSize(it.toInt())
        }
        SettingSlider("Assombrissement du fond", prefs.dim, 0f..0.8f, sliderColors, 0) { prefs.setDim(it) }

        TextButton(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }) { Text("Définir comme launcher par défaut", color = accent) }
    }
}

@Composable
fun SettingSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>,
    colors: SliderColors, steps: Int, onChange: (Float) -> Unit
) {
    Text(label, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
    Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps, colors = colors)
}
