package com.example.launcher

import android.app.Activity
import android.content.*
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.*
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

// ───────────────────────── Activity ─────────────────────────

class MainActivity : ComponentActivity() {
    private val homeSignal = mutableIntStateOf(0)
    private lateinit var prefs: Prefs

    private val pickImage = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) saveBackground(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val transparent = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        enableEdgeToEdge(statusBarStyle = transparent, navigationBarStyle = transparent)
        prefs = Prefs(this)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                LauncherRoot(prefs, homeSignal.intValue) {
                    pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        homeSignal.intValue++
    }

    // Copie la photo choisie dans le stockage de l'appli (redimensionnée)
    private fun saveBackground(uri: Uri) {
        CoroutineScope(Dispatchers.IO).launch {
            runCatching {
                val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
                var sample = 1
                while (bounds.outWidth / sample > 2200 || bounds.outHeight / sample > 2200) sample *= 2
                val opts = BitmapFactory.Options().apply { inSampleSize = sample }
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                val rot = contentResolver.openInputStream(uri)?.use {
                    when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                        else -> 0f
                    }
                } ?: 0f
                if (bmp != null) {
                    val finalBmp = if (rot != 0f) {
                        Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot) }, true)
                    } else bmp
                    File(filesDir, "bg.jpg").outputStream().use { out ->
                        finalBmp.compress(Bitmap.CompressFormat.JPEG, 90, out)
                    }
                    prefs.updateBgMode(2)
                    prefs.bumpBg()
                }
            }
        }
    }
}

// ───────────────────────── Catégories ─────────────────────────

// 0 = Tout, 1 = Jeux, 2 = Vidéo, 3 = Musique, 4 = Réseaux, 5 = Autres
// 6 = Favoris (onglet spécial)
val catNames = listOf("Tout", "Jeux", "Vidéo", "Musique", "Réseaux", "Autres", "Favoris")
val catIcons = listOf("📱", "🎮", "🎬", "🎵", "💬", "📦", "⭐")
val chipOrder = listOf(0, 6, 1, 2, 3, 4, 5)

private val kwGames = listOf(
    "game", "supercell", "candycrush", "roblox", "minecraft", "pubg", "garena", "gameloft",
    "mojang", "activision", "ubisoft", "rovio", "innersloth", "freefire", "nianticlabs",
    "mihoyo", "epicgames", "clashofclans", "brawlstars"
)
private val kwSocial = listOf(
    "facebook", "instagram", "whatsapp", "twitter", "tiktok", "musically", "zhiliaoapp",
    "snapchat", "telegram", "discord", "linkedin", "reddit", "messenger", "threads", "signal",
    "pinterest", "bereal", "mastodon", "viber", "wechat", "tumblr", "tinder", "bluesky"
)
private val kwMusic = listOf(
    "music", "spotify", "deezer", "soundcloud", "shazam", "tidal", "napster", "podcast",
    "radio", "musique", "audiomack"
)
private val kwVideo = listOf(
    "youtube", "netflix", "twitch", "avod", "primevideo", "disney", "vlc", "mxtech", "plex",
    "canal", "molotov", "dailymotion", "tf1", "francetv", "vimeo", "kodi", "crunchyroll",
    "snaptube", "video", "movie", "cinema"
)

fun classify(info: ApplicationInfo, label: String): Int {
    when (info.category) {
        ApplicationInfo.CATEGORY_GAME -> return 1
        ApplicationInfo.CATEGORY_VIDEO -> return 2
        ApplicationInfo.CATEGORY_AUDIO -> return 3
        ApplicationInfo.CATEGORY_SOCIAL -> return 4
    }
    val s = (info.packageName + " " + label).lowercase()
    return when {
        kwGames.any { it in s } -> 1
        kwSocial.any { it in s } -> 4
        kwMusic.any { it in s } -> 3
        kwVideo.any { it in s } -> 2
        else -> 5
    }
}

// ───────────────────────── Données ─────────────────────────

class AppItem(
    val label: String,
    val pkg: String,
    val cls: String,
    val icon: ImageBitmap,
    val auto: Int
)

class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    var accent by mutableIntStateOf(sp.getInt("accent", 0xFF7C4DFF.toInt())); private set
    var columns by mutableIntStateOf(sp.getInt("columns", 4)); private set
    var iconSize by mutableIntStateOf(sp.getInt("iconSize", 56)); private set
    var dim by mutableFloatStateOf(sp.getFloat("dim", 0.45f)); private set
    var dock by mutableStateOf(sp.getString("dock", "")!!.split("|").filter { it.isNotEmpty() }); private set

    // Arrière-plan : 0 = fond du téléphone, 1 = dégradé, 2 = photo, 3 = noir
    var bgMode by mutableIntStateOf(sp.getInt("bgMode", 0)); private set
    var bgVersion by mutableIntStateOf(0); private set
    // Animation du tiroir : 0 = glisse, 1 = zoom, 2 = fondu, 3 = pivot 3D
    var animStyle by mutableIntStateOf(sp.getInt("animStyle", 0)); private set
    // Animation des icônes : 0 = rebond, 1 = doux, 2 = aucune
    var pressStyle by mutableIntStateOf(sp.getInt("pressStyle", 0)); private set
    // Éléments de l'écran d'accueil
    var showCards by mutableStateOf(sp.getBoolean("showCards", false)); private set
    var showDock by mutableStateOf(sp.getBoolean("showDock", true)); private set
    // Style verre liquide
    var glass by mutableStateOf(sp.getBoolean("glass", true)); private set
    // Applis sur l'écran d'accueil
    var homeApps by mutableStateOf(sp.getString("home", "")!!.split("|").filter { it.isNotEmpty() }); private set
    // Horloge : style 0 = fin, 1 = gras, 2 = 3D ; alignement 0 = gauche, 1 = centre
    var clockStyle by mutableIntStateOf(sp.getInt("clockStyle", 0)); private set
    var clockSize by mutableIntStateOf(sp.getInt("clockSize", 78)); private set
    var clockAlign by mutableIntStateOf(sp.getInt("clockAlign", 0)); private set
    // Fond du tiroir : 0 = verre, 1 = sombre, 2 = couleur
    var drawerMode by mutableIntStateOf(sp.getInt("drawerMode", 0)); private set
    var drawerAlpha by mutableFloatStateOf(sp.getFloat("drawerAlpha", 0.55f)); private set
    var blurAmount by mutableIntStateOf(sp.getInt("blurAmount", 45)); private set
    // Favoris
    var favs by mutableStateOf(sp.getString("favs", "")!!.split("|").filter { it.isNotEmpty() }); private set
    var showFavs by mutableStateOf(sp.getBoolean("showFavs", true)); private set

    val overrides = mutableStateMapOf<String, Int>().apply {
        sp.getString("cats", "")!!.split(";").filter { it.contains("=") }.forEach { s ->
            val parts = s.split("=")
            parts[1].toIntOrNull()?.let { n -> put(parts[0], n) }
        }
    }

    fun catOf(a: AppItem): Int = overrides[a.pkg] ?: a.auto

    fun updateCat(pkg: String, c: Int) {
        if (c == 0) overrides.remove(pkg) else overrides[pkg] = c
        sp.edit().putString("cats", overrides.entries.joinToString(";") { "${it.key}=${it.value}" }).apply()
    }

    fun updateAccent(v: Int) { accent = v; sp.edit().putInt("accent", v).apply() }
    fun updateColumns(v: Int) { columns = v; sp.edit().putInt("columns", v).apply() }
    fun updateIconSize(v: Int) { iconSize = v; sp.edit().putInt("iconSize", v).apply() }
    fun updateDim(v: Float) { dim = v; sp.edit().putFloat("dim", v).apply() }
    fun updateBgMode(v: Int) { bgMode = v; sp.edit().putInt("bgMode", v).apply() }
    fun bumpBg() { bgVersion++ }
    fun updateAnimStyle(v: Int) { animStyle = v; sp.edit().putInt("animStyle", v).apply() }
    fun updatePressStyle(v: Int) { pressStyle = v; sp.edit().putInt("pressStyle", v).apply() }
    fun updateShowCards(v: Boolean) { showCards = v; sp.edit().putBoolean("showCards", v).apply() }
    fun updateShowDock(v: Boolean) { showDock = v; sp.edit().putBoolean("showDock", v).apply() }
    fun updateGlass(v: Boolean) { glass = v; sp.edit().putBoolean("glass", v).apply() }
    fun updateClockStyle(v: Int) { clockStyle = v; sp.edit().putInt("clockStyle", v).apply() }
    fun updateClockSize(v: Int) { clockSize = v; sp.edit().putInt("clockSize", v).apply() }
    fun updateClockAlign(v: Int) { clockAlign = v; sp.edit().putInt("clockAlign", v).apply() }
    fun updateDrawerMode(v: Int) { drawerMode = v; sp.edit().putInt("drawerMode", v).apply() }
    fun updateDrawerAlpha(v: Float) { drawerAlpha = v; sp.edit().putFloat("drawerAlpha", v).apply() }
    fun updateBlur(v: Int) { blurAmount = v; sp.edit().putInt("blurAmount", v).apply() }
    fun updateShowFavs(v: Boolean) { showFavs = v; sp.edit().putBoolean("showFavs", v).apply() }
    fun toggleFav(pkg: String) {
        favs = if (pkg in favs) favs - pkg else favs + pkg
        sp.edit().putString("favs", favs.joinToString("|")).apply()
    }
    fun toggleHome(pkg: String) {
        homeApps = if (pkg in homeApps) homeApps - pkg else if (homeApps.size < 20) homeApps + pkg else homeApps
        sp.edit().putString("home", homeApps.joinToString("|")).apply()
    }
    fun togglePin(pkg: String) {
        dock = if (pkg in dock) dock - pkg else if (dock.size < 5) dock + pkg else dock
        sp.edit().putString("dock", dock.joinToString("|")).apply()
    }
}

suspend fun loadApps(ctx: Context): List<AppItem> = withContext(Dispatchers.Default) {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    pm.queryIntentActivities(intent, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { ri ->
            val label = ri.loadLabel(pm).toString()
            AppItem(
                label,
                ri.activityInfo.packageName,
                ri.activityInfo.name,
                ri.loadIcon(pm).toBitmap(144, 144).asImageBitmap(),
                classify(ri.activityInfo.applicationInfo, label)
            )
        }
        .sortedBy { it.label.lowercase() }
}

fun loadBg(ctx: Context): ImageBitmap? {
    val f = File(ctx.filesDir, "bg.jpg")
    return if (f.exists()) BitmapFactory.decodeFile(f.absolutePath)?.asImageBitmap() else null
}

fun launchApp(ctx: Context, app: AppItem) {
    val i = Intent(Intent.ACTION_MAIN)
        .addCategory(Intent.CATEGORY_LAUNCHER)
        .setClassName(app.pkg, app.cls)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
    runCatching { ctx.startActivity(i) }
}

val swatches = listOf(
    0xFF7C4DFF, 0xFF00BCD4, 0xFFFF4081, 0xFFFF9800,
    0xFF4CAF50, 0xFF2196F3, 0xFFF44336, 0xFFFFEB3B
).map { it.toInt() }

// ───────────────────────── Verre liquide ─────────────────────────

fun Modifier.glassSurface(shape: Shape, tint: Color): Modifier = this
    .clip(shape)
    .background(Color.Black.copy(alpha = 0.18f))
    .background(
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.20f),
                Color.White.copy(alpha = 0.06f),
                tint.copy(alpha = 0.12f)
            )
        )
    )
    .drawBehind {
        drawRect(
            Brush.verticalGradient(
                listOf(Color.White.copy(alpha = 0.16f), Color.Transparent),
                endY = size.height * 0.45f
            )
        )
    }
    .border(
        1.dp,
        Brush.linearGradient(
            listOf(
                Color.White.copy(alpha = 0.8f),
                Color.White.copy(alpha = 0.06f),
                Color.White.copy(alpha = 0.4f)
            )
        ),
        shape
    )

fun Modifier.panel(glass: Boolean, shape: Shape, accent: Color, flatAlpha: Float = 0.2f): Modifier =
    if (glass) glassSurface(shape, accent)
    else this.clip(shape)
        .background(accent.copy(alpha = flatAlpha))
        .border(1.dp, accent.copy(alpha = 0.5f), shape)

// ───────────────────────── Contrôleur du tiroir ─────────────────────────

class DrawerCtl(private val scope: CoroutineScope) {
    var progress by mutableFloatStateOf(0f)
        private set
    private var job: Job? = null

    fun drag(delta: Float) {
        job?.cancel()
        progress = (progress + delta).coerceIn(0f, 1f)
    }

    fun settle(target: Float, velocity: Float = 0f) {
        job?.cancel()
        job = scope.launch {
            animate(progress, target, velocity, spring(dampingRatio = 1f, stiffness = 330f)) { v, _ ->
                progress = v.coerceIn(0f, 1f)
            }
        }
    }
}

// ───────────────────────── Écran principal ─────────────────────────

@Composable
fun LauncherRoot(prefs: Prefs, homeSignal: Int, onPickPhoto: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawer = remember { DrawerCtl(scope) }
    var apps by remember { mutableStateOf(emptyList<AppItem>()) }
    var refresh by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    var selectedCat by rememberSaveable { mutableIntStateOf(0) }
    val accent = Color(prefs.accent)

    val bgImage by produceState<ImageBitmap?>(null, prefs.bgVersion) {
        value = withContext(Dispatchers.IO) { loadBg(ctx) }
    }

    val counts by remember {
        derivedStateOf {
            IntArray(7).also { a ->
                a[0] = apps.size
                apps.forEach { a[prefs.catOf(it)]++ }
                a[6] = apps.count { it.pkg in prefs.favs }
            }
        }
    }

    DisposableEffect(Unit) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) { refresh++ }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(ctx, receiver, filter, ContextCompat.RECEIVER_EXPORTED)
        onDispose { ctx.unregisterReceiver(receiver) }
    }
    LaunchedEffect(refresh) { apps = loadApps(ctx) }

    LaunchedEffect(homeSignal) {
        if (homeSignal > 0) { showSettings = false; drawer.settle(0f) }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 31) {
            val w = (ctx as? Activity)?.window
            snapshotFlow { (drawer.progress * prefs.blurAmount).toInt() }.collect { r ->
                runCatching { w?.setBackgroundBlurRadius(r) }
            }
        }
    }

    val open by remember { derivedStateOf { drawer.progress > 0f } }
    LaunchedEffect(open) { if (!open) selectedCat = 0 }

    BackHandler(enabled = showSettings || open) {
        if (showSettings) showSettings = false else drawer.settle(0f)
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val hPx = constraints.maxHeight.toFloat()
        val range = hPx * 0.7f

        // Arrière-plan choisi
        when (prefs.bgMode) {
            1 -> Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(listOf(lerp(Color.Black, accent, 0.6f), Color(0xFF05050A)))
                )
            )
            2 -> {
                val img = bgImage
                if (img != null) {
                    Image(
                        img, null,
                        Modifier.fillMaxSize().graphicsLayer {
                            if (Build.VERSION.SDK_INT >= 31) {
                                val r = drawer.progress * prefs.blurAmount * 0.9f
                                renderEffect = if (r > 0.5f) BlurEffect(r, r, TileMode.Clamp) else null
                            }
                        },
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Box(Modifier.fillMaxSize().background(Color.Black))
                }
            }
            3 -> Box(Modifier.fillMaxSize().background(Color.Black))
        }

        // Voile coloré
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    listOf(accent.copy(alpha = 0.20f), Color.Black.copy(alpha = prefs.dim))
                )
            )
        )

        // ── Accueil ──
        Column(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    alpha = 1f - drawer.progress
                    val s = 1f - 0.06f * drawer.progress
                    scaleX = s; scaleY = s
                }
                .draggable(
                    state = rememberDraggableState { d -> drawer.drag(-d / range) },
                    orientation = Orientation.Vertical,
                    onDragStopped = { v ->
                        val t = when {
                            v < -700f -> 1f
                            v > 700f -> 0f
                            drawer.progress > 0.3f -> 1f
                            else -> 0f
                        }
                        drawer.settle(t, -v / range)
                    }
                )
                .pointerInput(Unit) { detectTapGestures(onLongPress = { showSettings = true }) }
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 24.dp)
        ) {
            Clock(prefs, accent)
            if (prefs.showCards) {
                Spacer(Modifier.height(16.dp))
                CategoryCards(apps, prefs, counts, accent) { c -> selectedCat = c; drawer.settle(1f) }
            }
            Spacer(Modifier.weight(1f))
            if (prefs.showFavs && prefs.favs.isNotEmpty()) {
                FavoritesRow(apps, prefs, accent) { launchApp(ctx, it) }
                Spacer(Modifier.height(12.dp))
            }
            if (prefs.homeApps.isNotEmpty()) {
                HomeGrid(apps, prefs, accent) { launchApp(ctx, it) }
                Spacer(Modifier.height(12.dp))
            }
            if (prefs.showDock && prefs.dock.isNotEmpty()) {
                Dock(apps, prefs, accent) { launchApp(ctx, it) }
            }
        }

        // ── Tiroir d'applis ──
        if (open) {
            Drawer(
                apps = apps, prefs = prefs, accent = accent, counts = counts,
                selectedCat = selectedCat, onSelectCat = { selectedCat = it },
                drawer = drawer, range = range,
                modifier = Modifier.graphicsLayer {
                    val p = drawer.progress
                    when (prefs.animStyle) {
                        1 -> {
                            val s = 0.8f + 0.2f * p
                            scaleX = s; scaleY = s
                            alpha = p
                        }
                        2 -> alpha = p
                        3 -> {
                            transformOrigin = TransformOrigin(0.5f, 1f)
                            rotationX = (1f - p) * 70f
                            cameraDistance = 14f * density
                            alpha = p
                        }
                        else -> {
                            translationY = (1f - p) * hPx * 0.6f
                            alpha = p
                        }
                    }
                },
                onLaunch = { launchApp(ctx, it) }
            )
        }

        // ── Réglages ──
        if (showSettings) {
            Box(
                Modifier.fillMaxSize().clickable(
                    interactionSource = remember { MutableInteractionSource() }, indication = null
                ) { showSettings = false }
            )
        }
        AnimatedVisibility(
            visible = showSettings,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(dampingRatio = 0.9f, stiffness = 300f)) { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            SettingsPanel(prefs, accent, onPickPhoto)
        }
    }
}

// ───────────────────────── Horloge ─────────────────────────

@Composable
fun Clock(prefs: Prefs, accent: Color) {
    val ctx = LocalContext.current
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(60_000L - now % 60_000L + 50L)
        }
    }
    val pattern = if (android.text.format.DateFormat.is24HourFormat(ctx)) "HH:mm" else "h:mm"
    val time = SimpleDateFormat(pattern, Locale.getDefault()).format(Date(now))
    val date = SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(Date(now))
        .replaceFirstChar { it.uppercase() }
    val size = prefs.clockSize.sp
    val align: Alignment.Horizontal =
        if (prefs.clockAlign == 1) Alignment.CenterHorizontally else Alignment.Start

    Column(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalAlignment = align) {
        when (prefs.clockStyle) {
            2 -> Clock3D(time, size, accent)
            1 -> Text(time, color = Color.White, fontSize = size, fontWeight = FontWeight.Bold)
            else -> Text(time, color = Color.White, fontSize = size, fontWeight = FontWeight.Thin)
        }
        Text(
            date, color = accent,
            fontSize = (prefs.clockSize * 0.23f).coerceIn(14f, 28f).sp,
            fontWeight = FontWeight.Medium
        )
    }
}

// Horloge en relief : plusieurs couches décalées + légère perspective
@Composable
fun Clock3D(text: String, size: TextUnit, accent: Color) {
    Box(
        Modifier
            .padding(end = 14.dp, bottom = 14.dp)
            .graphicsLayer {
                transformOrigin = TransformOrigin(0f, 0.5f)
                rotationY = -14f
                cameraDistance = 16f * density
            }
    ) {
        for (i in 12 downTo 1) {
            Text(
                text, fontSize = size, fontWeight = FontWeight.Black,
                color = lerp(accent, Color.Black, i / 14f),
                modifier = Modifier.offset(x = (i * 0.8f).dp, y = (i * 0.8f).dp)
            )
        }
        Text(
            text,
            style = androidx.compose.ui.text.TextStyle(
                brush = Brush.verticalGradient(listOf(Color.White, lerp(Color.White, accent, 0.55f))),
                fontSize = size,
                fontWeight = FontWeight.Black
            )
        )
    }
}

// ───────────────────────── Favoris ─────────────────────────

@Composable
fun FavoritesRow(apps: List<AppItem>, prefs: Prefs, accent: Color, onLaunch: (AppItem) -> Unit) {
    val items = prefs.favs.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }
    if (items.isEmpty()) return
    Column(
        Modifier
            .fillMaxWidth()
            .panel(prefs.glass, RoundedCornerShape(26.dp), accent, 0.18f)
            .padding(vertical = 12.dp)
    ) {
        Text(
            "⭐ Favoris", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(start = 16.dp, bottom = 6.dp)
        )
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp)) {
            items.forEach { app ->
                AppCell(
                    app, (prefs.iconSize - 6).dp, app.pkg in prefs.dock, true, accent,
                    prefs.catOf(app), prefs.pressStyle, app.pkg in prefs.homeApps, true,
                    { onLaunch(app) },
                    { prefs.togglePin(app.pkg) },
                    { prefs.toggleHome(app.pkg) },
                    { prefs.toggleFav(app.pkg) },
                    { c -> prefs.updateCat(app.pkg, c) }
                )
            }
        }
    }
}

// ───────────────────────── Applis de l'écran d'accueil ─────────────────────────

@Composable
fun HomeGrid(apps: List<AppItem>, prefs: Prefs, accent: Color, onLaunch: (AppItem) -> Unit) {
    val items = prefs.homeApps.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }
    val cols = minOf(prefs.columns, 5)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items.chunked(cols).forEach { row ->
            Row(Modifier.fillMaxWidth()) {
                row.forEach { app ->
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                        AppCell(
                            app, prefs.iconSize.dp, app.pkg in prefs.dock, true, accent,
                            prefs.catOf(app), prefs.pressStyle, true, app.pkg in prefs.favs,
                            { onLaunch(app) },
                            { prefs.togglePin(app.pkg) },
                            { prefs.toggleHome(app.pkg) },
                            { prefs.toggleFav(app.pkg) },
                            { c -> prefs.updateCat(app.pkg, c) }
                        )
                    }
                }
                repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

// ───────────────────────── Cartes de catégories (accueil) ─────────────────────────

@Composable
fun CategoryCards(
    apps: List<AppItem>, prefs: Prefs, counts: IntArray, accent: Color, onClick: (Int) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        listOf(listOf(1, 2), listOf(3, 4)).forEach { rowCats ->
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                rowCats.forEach { c ->
                    val previews = apps.filter { prefs.catOf(it) == c }.take(4)
                    Column(
                        Modifier
                            .weight(1f)
                            .panel(prefs.glass, RoundedCornerShape(22.dp), accent, 0.18f)
                            .clickable { onClick(c) }
                            .padding(14.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(catIcons[c], fontSize = 26.sp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(catNames[c], color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                                Text("${counts[c]} applis", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(
                            Modifier.height(30.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            previews.forEach { app ->
                                Image(app.icon, null, Modifier.size(30.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── Dock ─────────────────────────

@Composable
fun Dock(apps: List<AppItem>, prefs: Prefs, accent: Color, onLaunch: (AppItem) -> Unit) {
    val dockApps = prefs.dock.mapNotNull { p -> apps.firstOrNull { it.pkg == p } }
    Box(
        Modifier
            .fillMaxWidth()
            .panel(prefs.glass, RoundedCornerShape(32.dp), accent, 0.22f)
            .padding(12.dp),
        contentAlignment = Alignment.Center
    ) {
        if (dockApps.isEmpty()) {
            Text(
                "Appui long sur une appli (dans le tiroir) pour l'épingler ici",
                color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(12.dp)
            )
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                dockApps.forEach { app ->
                    AppCell(
                        app, prefs.iconSize.dp, true, false, accent, prefs.catOf(app), prefs.pressStyle,
                        app.pkg in prefs.homeApps, app.pkg in prefs.favs,
                        { onLaunch(app) },
                        { prefs.togglePin(app.pkg) },
                        { prefs.toggleHome(app.pkg) },
                        { prefs.toggleFav(app.pkg) },
                        { c -> prefs.updateCat(app.pkg, c) }
                    )
                }
            }
        }
    }
}

// ───────────────────────── Tiroir ─────────────────────────

@Composable
fun Drawer(
    apps: List<AppItem>, prefs: Prefs, accent: Color, counts: IntArray,
    selectedCat: Int, onSelectCat: (Int) -> Unit,
    drawer: DrawerCtl, range: Float, modifier: Modifier,
    onLaunch: (AppItem) -> Unit
) {
    var query by remember { mutableStateOf("") }
    val filtered by remember(apps, selectedCat, query) {
        derivedStateOf {
            apps.filter {
                (selectedCat == 0 ||
                    (if (selectedCat == 6) it.pkg in prefs.favs else prefs.catOf(it) == selectedCat)) &&
                    (query.isBlank() || it.label.contains(query, ignoreCase = true))
            }
        }
    }

    val connection = remember(range) {
        object : NestedScrollConnection {
            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (available.y > 0f && source == NestedScrollSource.UserInput) {
                    drawer.drag(-available.y / range)
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                if (drawer.progress < 1f) drawer.settle(if (drawer.progress > 0.6f) 1f else 0f)
                return Velocity.Zero
            }
        }
    }

    val a = prefs.drawerAlpha
    val drawerBrush: Brush = when (prefs.drawerMode) {
        1 -> Brush.verticalGradient(listOf(Color.Black.copy(alpha = a), Color.Black.copy(alpha = a)))
        2 -> Brush.verticalGradient(
            listOf(
                lerp(Color.Black, accent, 0.45f).copy(alpha = a),
                lerp(Color.Black, accent, 0.8f).copy(alpha = a)
            )
        )
        else -> Brush.verticalGradient(
            listOf(
                Color.Black.copy(alpha = a * 0.8f),
                lerp(Color.Black, accent, 0.35f).copy(alpha = (a * 1.1f).coerceAtMost(1f))
            )
        )
    }

    Column(
        modifier
            .fillMaxSize()
            .background(drawerBrush)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
    ) {
        BasicTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 17.sp),
            cursorBrush = SolidColor(accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { filtered.firstOrNull()?.let(onLaunch) }),
            modifier = Modifier
                .padding(horizontal = 20.dp, vertical = 14.dp)
                .fillMaxWidth()
                .panel(prefs.glass, RoundedCornerShape(28.dp), accent, 0.12f)
                .padding(horizontal = 20.dp, vertical = 14.dp),
            decorationBox = { inner ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("🔍", fontSize = 16.sp)
                    Spacer(Modifier.width(10.dp))
                    Box(Modifier.weight(1f)) {
                        if (query.isEmpty()) {
                            Text("Rechercher", color = Color.White.copy(alpha = 0.5f), fontSize = 17.sp)
                        }
                        inner()
                    }
                }
            }
        )

        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(chipOrder.size) { k ->
                val i = chipOrder[k]
                val sel = i == selectedCat
                val bg by animateColorAsState(
                    if (sel) accent else Color.White.copy(alpha = 0.10f), label = "chip"
                )
                Text(
                    "${catIcons[i]} ${catNames[i]}  ${counts[i]}",
                    color = if (sel) Color.Black else Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = (
                        if (sel) Modifier.clip(RoundedCornerShape(50)).background(bg)
                        else Modifier.panel(prefs.glass, RoundedCornerShape(50), accent, 0.10f)
                        )
                        .clickable { onSelectCat(i) }
                        .padding(horizontal = 16.dp, vertical = 9.dp)
                )
            }
        }

        Text(
            "${filtered.size} applications",
            color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(prefs.columns),
            modifier = Modifier.fillMaxSize().nestedScroll(connection),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filtered, key = { it.pkg + it.cls }, contentType = { 0 }) { app ->
                Box(Modifier.fillMaxWidth().animateItem(), contentAlignment = Alignment.Center) {
                    AppCell(
                        app, prefs.iconSize.dp, app.pkg in prefs.dock, true, accent,
                        prefs.catOf(app), prefs.pressStyle, app.pkg in prefs.homeApps,
                        app.pkg in prefs.favs,
                        { onLaunch(app) },
                        { prefs.togglePin(app.pkg) },
                        { prefs.toggleHome(app.pkg) },
                        { prefs.toggleFav(app.pkg) },
                        { c -> prefs.updateCat(app.pkg, c) }
                    )
                }
            }
        }
    }
}

// ───────────────────────── Icône d'appli ─────────────────────────

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AppCell(
    app: AppItem, size: Dp, pinned: Boolean, showLabel: Boolean, accent: Color, cat: Int,
    pressStyle: Int, homePinned: Boolean, favPinned: Boolean,
    onClick: () -> Unit, onTogglePin: () -> Unit, onToggleHome: () -> Unit,
    onToggleFav: () -> Unit, onSetCat: (Int) -> Unit
) {
    val ctx = LocalContext.current
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val target = if (!pressed) 1f else when (pressStyle) {
        0 -> 0.86f
        1 -> 0.93f
        else -> 1f
    }
    val scale by animateFloatAsState(
        target,
        if (pressStyle == 0) spring<Float>(dampingRatio = 0.5f, stiffness = 500f)
        else spring<Float>(dampingRatio = 1f, stiffness = 600f),
        label = "press"
    )
    var menu by remember { mutableStateOf(false) }
    var page by remember { mutableIntStateOf(0) }

    Box {
        Column(
            Modifier
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .combinedClickable(
                    interactionSource = source, indication = null,
                    onClick = onClick, onLongClick = { menu = true }
                )
                .padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.size(size)) {
                Image(app.icon, app.label, Modifier.fillMaxSize())
                if (favPinned) {
                    Text("⭐", fontSize = 12.sp, modifier = Modifier.align(Alignment.TopEnd))
                }
            }
            if (showLabel) {
                Text(
                    app.label, color = Color.White, fontSize = 11.sp, maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(top = 4.dp).widthIn(max = size + 16.dp)
                )
            }
        }
        DropdownMenu(
            expanded = menu,
            onDismissRequest = { menu = false; page = 0 },
            containerColor = Color(0xFF1E1E24)
        ) {
            if (page == 0) {
                DropdownMenuItem(
                    text = { Text(if (pinned) "Retirer du dock" else "Épingler au dock", color = Color.White) },
                    onClick = { menu = false; onTogglePin() }
                )
                DropdownMenuItem(
                    text = {
                        Text(if (favPinned) "Retirer des favoris" else "Ajouter aux favoris ⭐", color = Color.White)
                    },
                    onClick = { menu = false; onToggleFav() }
                )
                DropdownMenuItem(
                    text = {
                        Text(if (homePinned) "Retirer de l'accueil" else "Ajouter à l'accueil", color = Color.White)
                    },
                    onClick = { menu = false; onToggleHome() }
                )
                DropdownMenuItem(
                    text = { Text("Catégorie : ${catNames[cat]} …", color = Color.White) },
                    onClick = { page = 1 }
                )
                DropdownMenuItem(
                    text = { Text("Infos de l'appli", color = Color.White) },
                    onClick = {
                        menu = false
                        ctx.startActivity(
                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.pkg}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                )
                DropdownMenuItem(
                    text = { Text("Désinstaller", color = accent) },
                    onClick = {
                        menu = false
                        ctx.startActivity(
                            Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.pkg}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                )
            } else {
                listOf(1, 2, 3, 4, 5).forEach { c ->
                    DropdownMenuItem(
                        text = {
                            Text("${catIcons[c]} ${catNames[c]}", color = if (c == cat) accent else Color.White)
                        },
                        onClick = { menu = false; page = 0; onSetCat(c) }
                    )
                }
                DropdownMenuItem(
                    text = { Text("Automatique", color = Color.White.copy(alpha = 0.7f)) },
                    onClick = { menu = false; page = 0; onSetCat(0) }
                )
            }
        }
    }
}

// ───────────────────────── Réglages ─────────────────────────

@Composable
fun SectionLabel(text: String) {
    Text(
        text, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp,
        modifier = Modifier.padding(top = 14.dp)
    )
}

@Composable
fun SwitchRow(label: String, checked: Boolean, accent: Color, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = Color.White, fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = accent, checkedThumbColor = Color.Black)
        )
    }
}

@Composable
fun OptionChips(options: List<String>, selected: Int, accent: Color, onSelect: (Int) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEachIndexed { i, name ->
            val sel = i == selected
            Text(
                name,
                color = if (sel) Color.Black else Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clip(RoundedCornerShape(50))
                    .background(if (sel) accent else Color.White.copy(alpha = 0.12f))
                    .clickable { onSelect(i) }
                    .padding(horizontal = 16.dp, vertical = 9.dp)
            )
        }
    }
}

@Composable
fun SettingsPanel(prefs: Prefs, accent: Color, onPickPhoto: () -> Unit) {
    val ctx = LocalContext.current
    var hue by remember { mutableFloatStateOf(0f) }
    val hasPhoto = File(ctx.filesDir, "bg.jpg").exists()
    val sliderColors = SliderDefaults.colors(
        thumbColor = accent, activeTrackColor = accent, inactiveTrackColor = Color.White.copy(alpha = 0.2f)
    )

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(Color(0xE61A1A1F))
            .border(
                1.dp, Color.White.copy(alpha = 0.25f),
                RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)
            )
            .navigationBarsPadding()
            .heightIn(max = 640.dp)
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        Text("Personnalisation", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)

        SectionLabel("Écran d'accueil")
        SwitchRow("Cartes des catégories", prefs.showCards, accent) { prefs.updateShowCards(it) }
        SwitchRow("Dock (applis épinglées)", prefs.showDock, accent) { prefs.updateShowDock(it) }
        SwitchRow("Favoris sur l'accueil", prefs.showFavs, accent) { prefs.updateShowFavs(it) }
        SwitchRow("Style verre liquide", prefs.glass, accent) { prefs.updateGlass(it) }

        SectionLabel("Horloge")
        OptionChips(listOf("Fin", "Gras", "3D"), prefs.clockStyle, accent) { prefs.updateClockStyle(it) }
        OptionChips(listOf("Gauche", "Centre"), prefs.clockAlign, accent) { prefs.updateClockAlign(it) }
        SettingSlider(
            "Taille de l'horloge : ${prefs.clockSize}", prefs.clockSize.toFloat(), 40f..130f, sliderColors, 0
        ) { prefs.updateClockSize(it.toInt()) }

        SectionLabel("Couleur")
        LazyRow(
            Modifier.padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(swatches) { c ->
                Box(
                    Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color(c))
                        .border(if (c == prefs.accent) 3.dp else 0.dp, Color.White, CircleShape)
                        .clickable { prefs.updateAccent(c) }
                )
            }
        }
        Slider(
            value = hue,
            onValueChange = { hue = it; prefs.updateAccent(Color.hsv(it, 0.7f, 1f).toArgb()) },
            valueRange = 0f..360f, colors = sliderColors
        )

        SectionLabel("Arrière-plan")
        OptionChips(
            listOf("📱 Téléphone", "🎨 Dégradé", "🖼️ Photo", "⚫ Noir"),
            prefs.bgMode, accent
        ) { i ->
            if (i == 2 && !hasPhoto) onPickPhoto() else prefs.updateBgMode(i)
        }
        TextButton(onClick = onPickPhoto) {
            Text(if (hasPhoto) "Changer la photo de fond" else "Choisir une photo de fond", color = accent)
        }

        SectionLabel("Fond du tiroir")
        OptionChips(listOf("Verre", "Sombre", "Couleur"), prefs.drawerMode, accent) { prefs.updateDrawerMode(it) }
        SettingSlider(
            "Opacité : ${(prefs.drawerAlpha * 100).toInt()} %", prefs.drawerAlpha, 0.1f..0.95f, sliderColors, 0
        ) { prefs.updateDrawerAlpha(it) }
        SettingSlider(
            "Flou du fond : ${prefs.blurAmount}", prefs.blurAmount.toFloat(), 0f..80f, sliderColors, 0
        ) { prefs.updateBlur(it.toInt()) }

        SectionLabel("Animation du tiroir")
        OptionChips(
            listOf("Glisse", "Zoom", "Fondu", "Pivot 3D"),
            prefs.animStyle, accent
        ) { prefs.updateAnimStyle(it) }

        SectionLabel("Animation des icônes")
        OptionChips(
            listOf("Rebond", "Doux", "Aucune"),
            prefs.pressStyle, accent
        ) { prefs.updatePressStyle(it) }

        SettingSlider("Colonnes : ${prefs.columns}", prefs.columns.toFloat(), 3f..6f, sliderColors, 2) {
            prefs.updateColumns(it.toInt())
        }
        SettingSlider("Taille des icônes : ${prefs.iconSize}", prefs.iconSize.toFloat(), 40f..72f, sliderColors, 0) {
            prefs.updateIconSize(it.toInt())
        }
        SettingSlider("Assombrissement du fond", prefs.dim, 0f..0.8f, sliderColors, 0) { prefs.updateDim(it) }

        TextButton(onClick = {
            ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }) { Text("Définir comme launcher par défaut", color = accent) }
    }
}

@Composable
fun SettingSlider(
    label: String, value: Float, range: ClosedFloatingPointRange<Float>,
    colors: SliderColors, steps: Int, onChange: (Float) -> Unit
) {
    Text(label, color = Color.White.copy(alpha = 0.7f), fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
    Slider(value = value, onValueChange = onChange, valueRange = range, steps = steps, colors = colors)
}
