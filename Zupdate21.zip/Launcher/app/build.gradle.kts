plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.example.launcher"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.example.launcher"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "1.2"
        // Seulement les téléphones 64 bits (Xiaomi récents) : APK plus léger
        ndk { abiFilters += listOf("arm64-v8a") }
    }
    buildTypes {
        // Version optimisée (beaucoup plus fluide qu'un build debug classique)
        debug {
            isDebuggable = false
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.15.0")
    // Contrôle par la main : caméra + reconnaissance des gestes
    implementation("androidx.camera:camera-camera2:1.3.4")
    implementation("androidx.camera:camera-lifecycle:1.3.4")
    implementation("androidx.lifecycle:lifecycle-service:2.8.7")
    implementation("com.google.mediapipe:tasks-vision:0.10.14")
}

// Modèle de reconnaissance des gestes de Google, téléchargé pendant la compilation
val downloadHandModel by tasks.registering {
    val out = layout.projectDirectory.file("src/main/assets/gesture_recognizer.task").asFile
    outputs.file(out)
    doLast {
        if (!out.exists() || out.length() < 1000L) {
            out.parentFile.mkdirs()
            java.net.URL(
                "https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/1/gesture_recognizer.task"
            ).openStream().use { input ->
                out.outputStream().use { input.copyTo(it) }
            }
        }
    }
}
tasks.named("preBuild") { dependsOn(downloadHandModel) }
