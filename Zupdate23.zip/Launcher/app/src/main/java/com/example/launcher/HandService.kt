package com.example.launcher

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleService
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizerResult
import java.util.concurrent.Executors
import kotlin.math.abs

// Regarde ta main avec la caméra avant et envoie les gestes au service d'accessibilité
class HandService : LifecycleService() {

    private var recognizer: GestureRecognizer? = null
    private var provider: ProcessCameraProvider? = null
    private val executor = Executors.newSingleThreadExecutor()
    private var cameraStarted = false
    private var lastFrame = 0L

    // état des gestes (utilisé seulement par le thread de reconnaissance)
    private var held = ""
    private var heldSince = 0L
    private var fired = false
    private var lastAction = 0L
    private var lastScroll = 0L
    private val hist = mutableListOf<Pair<Long, Float>>()

    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i?.action == Intent.ACTION_SCREEN_OFF) {
                provider?.unbindAll()
            } else if (i?.action == Intent.ACTION_SCREEN_ON) {
                startCamera()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        startInForeground()
        setupRecognizer()
        val f = IntentFilter(Intent.ACTION_SCREEN_OFF).apply { addAction(Intent.ACTION_SCREEN_ON) }
        ContextCompat.registerReceiver(this, screenReceiver, f, ContextCompat.RECEIVER_EXPORTED)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (intent?.action == "STOP") {
            getSharedPreferences("launcher", MODE_PRIVATE).edit().putBoolean("handEnabled", false).apply()
            stopSelf()
            return START_NOT_STICKY
        }
        if (!cameraStarted) {
            cameraStarted = true
            startCamera()
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(screenReceiver) }
        runCatching { provider?.unbindAll() }
        runCatching { recognizer?.close() }
        executor.shutdown()
        super.onDestroy()
    }

    private fun startInForeground() {
        val channelId = "hand"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Contrôle par la main", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0, Intent(this, HandService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Contrôle par la main actif")
            .setContentText("La caméra avant surveille ta main")
            .setOngoing(true)
            .addAction(0, "Arrêter", stop)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA)
        } else {
            startForeground(1, n)
        }
    }

    private fun setupRecognizer() {
        try {
            val base = BaseOptions.builder().setModelAssetPath("gesture_recognizer.task").build()
            val options = GestureRecognizer.GestureRecognizerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setResultListener { result, _ -> handle(result) }
                .setErrorListener { e -> Log.e("HandService", "erreur", e) }
                .build()
            recognizer = GestureRecognizer.createFromOptions(this, options)
        } catch (e: Exception) {
            Log.e("HandService", "reconnaissance impossible", e)
        }
    }

    private fun startCamera() {
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            try {
                val p = future.get()
                provider = p
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                    .build()
                analysis.setAnalyzer(executor) { proxy -> analyze(proxy) }
                p.unbindAll()
                p.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, analysis)
            } catch (e: Exception) {
                Log.e("HandService", "caméra impossible", e)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyze(proxy: ImageProxy) {
        try {
            val now = SystemClock.uptimeMillis()
            if (now - lastFrame < 60) return
            lastFrame = now
            val rec = recognizer ?: return
            val bmp = proxy.toBitmap()
            val rot = proxy.imageInfo.rotationDegrees
            val upright = if (rot != 0) {
                Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
            } else bmp
            rec.recognizeAsync(BitmapImageBuilder(upright).build(), now)
        } catch (e: Exception) {
            Log.e("HandService", "image", e)
        } finally {
            proxy.close()
        }
    }

    private fun handle(result: GestureRecognizerResult) {
        val now = SystemClock.uptimeMillis()
        val top = result.gestures().firstOrNull()?.firstOrNull()
        if (top == null || top.score() < 0.6f) {
            held = ""
            hist.clear()
            return
        }
        val name = top.categoryName()
        val sens = getSharedPreferences("launcher", MODE_PRIVATE).getInt("handSens", 5).coerceIn(1, 10)

        // Main ouverte qui monte ou descend vite : défilement
        if (name == "Open_Palm") {
            val lm = result.landmarks().firstOrNull()
            if (lm != null && lm.isNotEmpty()) {
                val cy = lm.map { it.y() }.average().toFloat()
                hist.add(now to cy)
                while (hist.isNotEmpty() && now - hist.first().first > 450) hist.removeAt(0)
                val dy = cy - hist.first().second
                val trig = 0.24f - sens * 0.014f
                if (now - lastScroll > 600 && abs(dy) > trig) {
                    lastScroll = now
                    hist.clear()
                    HandAccessibility.instance?.act(if (dy > 0) "down" else "up")
                    buzz()
                }
            }
            held = ""
            return
        }
        hist.clear()

        // Gestes à tenir environ 0,7 seconde
        val action = when (name) {
            "Closed_Fist" -> "back"
            "Thumb_Up" -> "home"
            "Victory" -> "shot"
            else -> null
        }
        if (action == null) {
            held = ""
            return
        }
        if (name != held) {
            held = name
            heldSince = now
            fired = false
        }
        if (!fired && now - heldSince > 700 && now - lastAction > 1500) {
            fired = true
            lastAction = now
            HandAccessibility.instance?.act(action)
            buzz()
        }
    }

    private fun buzz() {
        runCatching {
            (getSystemService(VIBRATOR_SERVICE) as? Vibrator)
                ?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
        }
    }
}
