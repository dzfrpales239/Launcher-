package com.example.launcher

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

// Exécute les gestes de la main (défiler, retour, accueil, capture) et les actions système du launcher
class HandAccessibility : AccessibilityService() {

    companion object {
        @Volatile
        var instance: HandAccessibility? = null
    }

    @Volatile
    private var currentPkg: String = ""

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val p = event.packageName?.toString() ?: return
            if (p != "com.android.systemui" && !p.contains("inputmethod") && !p.contains("keyboard")) {
                currentPkg = p
            }
        }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    private fun allowed(): Boolean {
        val sp = getSharedPreferences("launcher", MODE_PRIVATE)
        if (sp.getBoolean("handAllApps", true)) return true
        return currentPkg in sp.getString("handApps", "")!!.split("|")
    }

    // Gestes de la main (filtrés par applis et par réglages)
    fun act(action: String) {
        Handler(Looper.getMainLooper()).post {
            if (allowed()) {
                val sp = getSharedPreferences("launcher", MODE_PRIVATE)
                when (action) {
                    "back" -> if (sp.getBoolean("handBack", true)) performGlobalAction(GLOBAL_ACTION_BACK)
                    "home" -> if (sp.getBoolean("handHome", true)) performGlobalAction(GLOBAL_ACTION_HOME)
                    "shot" -> if (sp.getBoolean("handShot", true) && Build.VERSION.SDK_INT >= 28) {
                        performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
                    }
                    "down", "up" -> if (sp.getBoolean("handScroll", true)) {
                        val invert = sp.getBoolean("handInvert", false)
                        swipe((action == "down") != invert)
                    }
                }
            }
            Unit
        }
    }

    // Actions demandées par le launcher (centre de contrôle, gestes de l'accueil, récentes)
    fun system(action: String) {
        Handler(Looper.getMainLooper()).post {
            when (action) {
                "lock" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
                "notif" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
                "quick" -> performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
                "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
                "shot" -> if (Build.VERSION.SDK_INT >= 28) performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            }
            Unit
        }
    }

    // Défiler vers le bas = le doigt glisse vers le haut
    private fun swipe(scrollDown: Boolean) {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val y1 = dm.heightPixels * (if (scrollDown) 0.72f else 0.28f)
        val y2 = dm.heightPixels * (if (scrollDown) 0.28f else 0.72f)
        val path = Path().apply {
            moveTo(x, y1)
            lineTo(x, y2)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 280))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
