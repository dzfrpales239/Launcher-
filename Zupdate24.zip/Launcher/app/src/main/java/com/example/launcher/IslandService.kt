package com.example.launcher

import android.animation.ValueAnimator
import android.app.Notification
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

// Île dynamique : capsule noire en haut de l'écran
// (musique, notifications, appels, minuteurs / chronomètres, charge)
class IslandService : NotificationListenerService() {

    private val handler = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var root: FrameLayout? = null
    private var wlp: WindowManager.LayoutParams? = null

    private lateinit var card: LinearLayout
    private lateinit var icon: ImageView
    private lateinit var spacer: View
    private lateinit var textCol: LinearLayout
    private lateinit var title: TextView
    private lateinit var subtitle: TextView
    private lateinit var timeView: TextView
    private lateinit var eq: EqView
    private lateinit var controls: LinearLayout
    private lateinit var actionsRow: LinearLayout
    private val bg = GradientDrawable().apply { setColor(Color.BLACK) }
    private var sizeAnim: ValueAnimator? = null
    private var stateKey = ""

    private var controller: MediaController? = null
    private var controllerKey: String? = null

    // alerte : notification, appel entrant ou charge
    private var alertKey: String? = null
    private var alertTitle = ""
    private var alertText = ""
    private var alertIcon: Drawable? = null
    private var alertIntent: PendingIntent? = null
    private var alertActions: List<Notification.Action> = emptyList()
    private var alertUntil = 0L

    // activité en direct : minuteur, chronomètre, appel en cours
    private var liveKey: String? = null
    private var liveTitle = ""
    private var liveSub = ""
    private var liveIcon: Drawable? = null
    private var liveWhen = 0L
    private var liveCountDown = false
    private var liveIntent: PendingIntent? = null
    private var liveActions: List<Notification.Action> = emptyList()

    private var mediaExpanded = false
    private var mode = 0 // 0 rien, 1 alerte, 2 musique, 3 activité en direct
    private var receiverRegistered = false

    private val collapseRun = Runnable {
        mediaExpanded = false
        refresh()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (mode == 3 && root != null) {
                updateTime()
                handler.postDelayed(this, 1000)
            }
        }
    }

    private val mediaCb = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) { refresh() }
        override fun onPlaybackStateChanged(state: PlaybackState?) { refresh() }
    }

    private val prefsListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key != null && key.startsWith("island")) handler.post { refresh() }
    }

    private val powerReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i?.action == Intent.ACTION_POWER_CONNECTED) showCharge()
        }
    }

    private fun dp(v: Float): Int = (v * resources.displayMetrics.density).toInt()

    // ───────── Cycle de vie ─────────

    override fun onListenerConnected() {
        super.onListenerConnected()
        getSharedPreferences("launcher", MODE_PRIVATE).registerOnSharedPreferenceChangeListener(prefsListener)
        if (!receiverRegistered) {
            ContextCompat.registerReceiver(
                this, powerReceiver, IntentFilter(Intent.ACTION_POWER_CONNECTED), ContextCompat.RECEIVER_EXPORTED
            )
            receiverRegistered = true
        }
        runCatching {
            activeNotifications?.forEach { sbn ->
                mediaToken(sbn.notification)?.let { bindMedia(sbn.key, it) }
            }
        }
        handler.post { refresh() }
    }

    override fun onListenerDisconnected() {
        getSharedPreferences("launcher", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefsListener)
        if (receiverRegistered) {
            runCatching { unregisterReceiver(powerReceiver) }
            receiverRegistered = false
        }
        hide()
        super.onListenerDisconnected()
    }

    override fun onDestroy() {
        hide()
        if (receiverRegistered) {
            runCatching { unregisterReceiver(powerReceiver) }
            receiverRegistered = false
        }
        runCatching { controller?.unregisterCallback(mediaCb) }
        super.onDestroy()
    }

    // ───────── Notifications ─────────

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val n = sbn.notification
        val token = mediaToken(n)
        if (token != null) {
            bindMedia(sbn.key, token)
            handler.post { refresh() }
            return
        }
        if (sbn.packageName == packageName) return
        val sp = getSharedPreferences("launcher", MODE_PRIVATE)
        val extras = n.extras
        val t = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val x = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val appIcon = runCatching { packageManager.getApplicationIcon(sbn.packageName) }.getOrNull()
        val actions = n.actions?.toList().orEmpty().take(2)

        // Minuteur, chronomètre, appel en cours : tout ce qui affiche un compteur
        if (extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)) {
            if (sp.getBoolean("islandLive", true)) {
                liveKey = sbn.key
                liveTitle = t
                liveSub = x
                liveIcon = appIcon
                liveWhen = n.`when`
                liveCountDown = extras.getBoolean(Notification.EXTRA_CHRONOMETER_COUNT_DOWN)
                liveIntent = n.contentIntent
                liveActions = actions
                handler.post { refresh() }
            }
            return
        }

        if (!sp.getBoolean("islandNotifs", true)) return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val isCall = n.category == Notification.CATEGORY_CALL
        val ongoing = (n.flags and Notification.FLAG_ONGOING_EVENT) != 0 ||
            (n.flags and Notification.FLAG_FOREGROUND_SERVICE) != 0
        if (!isCall && ongoing) return
        if (t.isBlank() && x.isBlank()) return
        alertKey = sbn.key
        alertTitle = t
        alertText = x
        alertIntent = n.contentIntent
        alertIcon = appIcon
        alertActions = if (isCall) actions else emptyList()
        val duration = if (isCall) 120_000L else 4_500L
        alertUntil = SystemClock.uptimeMillis() + duration
        handler.post { refresh() }
        handler.postDelayed({ refresh() }, duration + 100)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.key == alertKey) {
            alertKey = null
            alertUntil = 0L
        }
        if (sbn.key == liveKey) {
            liveKey = null
        }
        if (sbn.key == controllerKey) {
            runCatching { controller?.unregisterCallback(mediaCb) }
            controller = null
            controllerKey = null
        }
        handler.post { refresh() }
    }

    @Suppress("DEPRECATION")
    private fun mediaToken(n: Notification): MediaSession.Token? {
        val e = n.extras
        return if (Build.VERSION.SDK_INT >= 33) {
            e.getParcelable(Notification.EXTRA_MEDIA_SESSION, MediaSession.Token::class.java)
        } else {
            e.getParcelable(Notification.EXTRA_MEDIA_SESSION)
        }
    }

    private fun bindMedia(key: String, token: MediaSession.Token) {
        if (controllerKey == key && controller != null) return
        runCatching { controller?.unregisterCallback(mediaCb) }
        controller = MediaController(this, token).also { it.registerCallback(mediaCb, handler) }
        controllerKey = key
    }

    // ───────── Charge ─────────

    private fun showCharge() {
        val sp = getSharedPreferences("launcher", MODE_PRIVATE)
        if (!sp.getBoolean("islandCharge", true)) return
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0 && scale > 0) level * 100 / scale else -1
        alertKey = "charge"
        alertTitle = "Charge en cours"
        alertText = if (pct >= 0) "$pct %" else ""
        alertIcon = ContextCompat.getDrawable(this, android.R.drawable.ic_lock_idle_charging)
        alertIntent = null
        alertActions = emptyList()
        alertUntil = SystemClock.uptimeMillis() + 3_500L
        handler.post { refresh() }
        handler.postDelayed({ refresh() }, 3_600L)
    }

    // ───────── Affichage ─────────

    private fun refresh() {
        val sp = getSharedPreferences("launcher", MODE_PRIVATE)
        val enabled = sp.getBoolean("islandEnabled", false) && Settings.canDrawOverlays(this)
        if (!enabled) {
            hide()
            return
        }
        val now = SystemClock.uptimeMillis()
        val c = controller
        val playing = sp.getBoolean("islandMedia", true) && c != null &&
            c.playbackState?.state == PlaybackState.STATE_PLAYING
        val alerting = alertKey != null && now < alertUntil
        val living = liveKey != null && sp.getBoolean("islandLive", true)
        mode = if (alerting) 1 else if (living) 3 else if (playing) 2 else 0
        if (mode == 0) {
            hide()
            return
        }
        ensureShown(sp)

        val sw = resources.displayMetrics.widthPixels
        val expW = minOf(sw - dp(24f), dp(360f))
        val expanded: Boolean
        var actions: List<Notification.Action> = emptyList()
        when (mode) {
            1 -> {
                expanded = true
                icon.setImageDrawable(alertIcon)
                title.text = alertTitle
                subtitle.text = alertText
                subtitle.visibility = if (alertText.isBlank()) View.GONE else View.VISIBLE
                actions = alertActions
            }
            3 -> {
                expanded = mediaExpanded
                icon.setImageDrawable(liveIcon)
                title.text = liveTitle
                subtitle.text = liveSub
                subtitle.visibility = if (liveSub.isBlank()) View.GONE else View.VISIBLE
                actions = if (expanded) liveActions else emptyList()
            }
            else -> {
                expanded = mediaExpanded
                val md = c?.metadata
                val art = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                if (art != null) {
                    icon.setImageBitmap(art)
                } else {
                    icon.setImageDrawable(
                        runCatching { packageManager.getApplicationIcon(c?.packageName ?: "") }.getOrNull()
                    )
                }
                title.text = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: "Lecture en cours"
                val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST).orEmpty()
                subtitle.text = artist
                subtitle.visibility = if (artist.isBlank()) View.GONE else View.VISIBLE
            }
        }
        eq.visibility = if (mode == 2) View.VISIBLE else View.GONE
        timeView.visibility = if (mode == 3) View.VISIBLE else View.GONE
        controls.visibility = if (mode == 2 && expanded) View.VISIBLE else View.GONE
        setActions(actions)
        textCol.visibility = if (expanded) View.VISIBLE else View.GONE
        spacer.visibility = if (expanded) View.GONE else View.VISIBLE
        val isz = if (expanded) dp(40f) else dp(24f)
        (icon.layoutParams as LinearLayout.LayoutParams).apply { width = isz; height = isz }
        icon.requestLayout()

        if (mode == 3) {
            updateTime()
            handler.removeCallbacks(tick)
            handler.postDelayed(tick, 1000)
        }

        val hasActions = actions.isNotEmpty()
        val key = "$mode-$expanded-$hasActions"
        if (key != stateKey) {
            stateKey = key
            when {
                mode == 1 || (mode == 3 && expanded) ->
                    animateTo(expW, if (hasActions) dp(108f) else dp(64f), dp(28f))
                mode == 2 && expanded -> animateTo(expW, dp(100f), dp(30f))
                else -> animateTo(dp(150f), dp(36f), dp(18f))
            }
        }
    }

    private fun updateTime() {
        if (mode != 3) return
        val nowMs = System.currentTimeMillis()
        val diff = if (liveCountDown) liveWhen - nowMs else nowMs - liveWhen
        val s = maxOf(0L, diff / 1000)
        timeView.text = if (s >= 3600) {
            "%d:%02d:%02d".format(s / 3600, (s % 3600) / 60, s % 60)
        } else {
            "%02d:%02d".format(s / 60, s % 60)
        }
    }

    private fun setActions(list: List<Notification.Action>) {
        actionsRow.removeAllViews()
        for (a in list) {
            val tv = TextView(this)
            tv.text = a.title
            tv.textSize = 14f
            tv.typeface = Typeface.DEFAULT_BOLD
            tv.setTextColor(Color.WHITE)
            tv.setPadding(dp(18f), dp(8f), dp(18f), dp(8f))
            tv.background = GradientDrawable().apply {
                setColor(Color.argb(60, 255, 255, 255))
                cornerRadius = dp(18f).toFloat()
            }
            tv.setOnClickListener {
                try {
                    a.actionIntent?.send()
                } catch (e: Exception) {
                    // ignoré
                }
            }
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
            lp.setMargins(dp(6f), 0, dp(6f), dp(8f))
            actionsRow.addView(tv, lp)
        }
        actionsRow.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun ensureShown(sp: SharedPreferences) {
        val y = dp(sp.getInt("islandY", 6).toFloat())
        if (root == null) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            buildViews()
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                this.y = y
                if (Build.VERSION.SDK_INT >= 30) {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                } else if (Build.VERSION.SDK_INT >= 28) {
                    layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
            wlp = lp
            val r = root!!
            r.alpha = 0f
            runCatching { wm?.addView(r, lp) }
            r.animate().alpha(1f).setDuration(180).start()
            stateKey = ""
        } else {
            val lp = wlp
            if (lp != null && lp.y != y) {
                lp.y = y
                runCatching { wm?.updateViewLayout(root, lp) }
            }
        }
    }

    private fun hide() {
        handler.removeCallbacks(collapseRun)
        handler.removeCallbacks(tick)
        val r = root ?: return
        root = null
        stateKey = ""
        mediaExpanded = false
        r.animate().alpha(0f).setDuration(150).withEndAction {
            runCatching { wm?.removeView(r) }
        }.start()
    }

    private fun animateTo(w: Int, h: Int, radius: Int) {
        val lp = card.layoutParams
        val w0 = if (lp.width > 0) lp.width else dp(60f)
        val h0 = if (lp.height > 0) lp.height else dp(30f)
        val r0 = bg.cornerRadius
        sizeAnim?.cancel()
        sizeAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 380
            interpolator = OvershootInterpolator(0.7f)
            addUpdateListener { v ->
                val t = v.animatedValue as Float
                lp.width = maxOf(1, (w0 + (w - w0) * t).toInt())
                lp.height = maxOf(1, (h0 + (h - h0) * t).toInt())
                bg.cornerRadius = maxOf(0f, r0 + (radius - r0) * t)
                card.layoutParams = lp
            }
            start()
        }
    }

    private fun onCardClick() {
        when (mode) {
            1 -> {
                try {
                    alertIntent?.send()
                } catch (e: Exception) {
                    // ignoré
                }
                alertUntil = 0L
                refresh()
            }
            2 -> {
                mediaExpanded = !mediaExpanded
                handler.removeCallbacks(collapseRun)
                if (mediaExpanded) handler.postDelayed(collapseRun, 6000)
                refresh()
            }
            3 -> {
                if (!mediaExpanded) {
                    mediaExpanded = true
                    handler.removeCallbacks(collapseRun)
                    handler.postDelayed(collapseRun, 6000)
                } else {
                    try {
                        liveIntent?.send()
                    } catch (e: Exception) {
                        // ignoré
                    }
                    mediaExpanded = false
                }
                refresh()
            }
        }
    }

    private fun togglePlay() {
        val c = controller ?: return
        if (c.playbackState?.state == PlaybackState.STATE_PLAYING) {
            c.transportControls.pause()
        } else {
            c.transportControls.play()
        }
    }

    private fun buildViews() {
        val r = FrameLayout(this)
        card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            gravity = Gravity.CENTER_VERTICAL
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10f), 0, dp(14f), 0)
        }
        icon = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) {
                    o.setRoundRect(0, 0, v.width, v.height, v.width * 0.28f)
                }
            }
            clipToOutline = true
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(24f), dp(24f)))
        spacer = View(this)
        row.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        textCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10f), 0, dp(10f), 0)
        }
        title = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        subtitle = TextView(this).apply {
            setTextColor(Color.argb(190, 255, 255, 255))
            textSize = 12f
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        textCol.addView(title)
        textCol.addView(subtitle)
        row.addView(textCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        timeView = TextView(this).apply {
            setTextColor(Color.rgb(255, 214, 10))
            textSize = 13f
            typeface = Typeface.MONOSPACE
            visibility = View.GONE
        }
        val timeLp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
        )
        timeLp.marginStart = dp(8f)
        row.addView(timeView, timeLp)
        eq = EqView(this)
        row.addView(eq, LinearLayout.LayoutParams(dp(18f), dp(16f)))
        card.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        fun button(label: String, action: () -> Unit): TextView {
            val tv = TextView(this)
            tv.text = label
            tv.textSize = 22f
            tv.setTextColor(Color.WHITE)
            tv.setPadding(dp(22f), dp(2f), dp(22f), dp(8f))
            tv.setOnClickListener { action() }
            return tv
        }
        controls.addView(button("⏮") { controller?.transportControls?.skipToPrevious() })
        controls.addView(button("⏯") { togglePlay() })
        controls.addView(button("⏭") { controller?.transportControls?.skipToNext() })
        card.addView(
            controls,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        actionsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            visibility = View.GONE
        }
        card.addView(
            actionsRow,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        card.setOnClickListener { onCardClick() }
        r.addView(card, FrameLayout.LayoutParams(dp(60f), dp(30f), Gravity.CENTER_HORIZONTAL))
        root = r
    }

    // Petites barres animées pendant la lecture
    private class EqView(ctx: Context) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(255, 214, 10) }
        private var t = 0f
        private val anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 900
            repeatCount = ValueAnimator.INFINITE
            addUpdateListener {
                t = it.animatedValue as Float
                invalidate()
            }
        }

        override fun onAttachedToWindow() {
            super.onAttachedToWindow()
            anim.start()
        }

        override fun onDetachedFromWindow() {
            anim.cancel()
            super.onDetachedFromWindow()
        }

        override fun onDraw(canvas: Canvas) {
            val w = width.toFloat()
            val h = height.toFloat()
            val bw = w / 5f
            for (i in 0 until 3) {
                val f = 0.35f + 0.65f * abs(sin((t * 2.0 * PI + i * 1.3).toFloat()))
                val bh = h * f
                canvas.drawRoundRect(i * 2 * bw, h - bh, i * 2 * bw + bw, h, bw / 2, bw / 2, paint)
            }
        }
    }
}
